import edu.princeton.cs.algs4.StdOut;

public class BruteCollinearPoints {
    private int segNum;
    private LineSegment[] data;


    public BruteCollinearPoints(Point[] points){
        data = null;
        if (points == null) throw new NullPointerException("?");

        Point[] points_process = new Point[points.length];

        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) throw new NullPointerException("?");

            for (int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0) throw new IllegalArgumentException("?");
            }

            points_process[i] = points[i];
        }




        mergeSortForPoints(points_process);

        for (int m = 0; m < points_process.length; m++) {
            for (int n = m + 1; n < points_process.length; n ++) {
                for (int o = n + 1; o < points_process.length; o++) {
                    for (int p = o + 1; p < points_process.length; p++) {
                        if (points_process[m].slopeTo(points_process[n]) == points_process[m].slopeTo(points_process[o])) {
                            if (points_process[m].slopeTo(points_process[n]) == points_process[m].slopeTo(points_process[p])) {
                                if (segNum == 0) {
                                    data = new LineSegment[1];
                                    data[segNum++] = new LineSegment(points_process[m], points_process[p]);
                                } else if (segNum >= data.length - 1) {
                                    LineSegment[] temp = new LineSegment[data.length * 2];
                                    for (int i = 0; i < segNum; i++)
                                        temp[i] = data[i];
                                    data = temp;
                                    data[segNum++] = new LineSegment(points_process[m], points_process[p]);
                                } else  data[segNum++] = new LineSegment(points_process[m], points_process[p]);
                            }
                        }
                    }
                }
            }
        }

        if (segNum < data.length) {
            LineSegment[] temp = new LineSegment[segNum];
            for (int i = 0; i < segNum; i++) {
                temp[i] = data[i];
            }
            data = temp;
        }
    }


    public int numberOfSegments() { return segNum;}

    public LineSegment[] segments() {
        LineSegment[] outputdata = new LineSegment[segNum];
        for (int i = 0; i < segNum; i++) {
            outputdata[i] = data[i];
        }
        return outputdata;
    }

    private void mergeSortForPoints(Point[] points) {
        Point[] aux = new Point[points.length];
        sort(points, aux, 0, points.length - 1);
    }

    private boolean less(Point v, Point w) {
        return (v.compareTo(w) < 0);
    }

    private boolean isSorted( Point[] a, int lo, int hi) {
        for (int i = lo; i <= hi; i++) {
            if (less(a[i], a[i - 1])) return false;
        }
        return true;
    }

    private void merge(Point[] a, Point[] aux, int lo, int mid, int hi) {
        //可以同时使用多种排序依据的merge
        assert isSorted(a, lo, mid);
        assert isSorted(a, mid + 1, hi);

        for (int k = lo; k <=hi; k++)
            aux[k] = a[k];

        int i = lo, j = mid + 1;
        for (int k = lo; k <= hi; k++) {
            if (i > mid) {
                a[k] = aux[j++];
            } else if (j > hi) {
                a[k] = aux[i++];
            } else if (less(aux[j], aux[i])) {
                a[k] = aux[j++];
            } else {
                a[k] = aux[i++];
            }
        }
    }

    private void sort(Point[] a, Point[] aux, int lo, int hi) {
        if (hi <= lo) return;
        int mid = lo + (hi - lo) / 2;
        sort(a, aux, lo, mid);
        sort(a, aux, mid + 1, hi);
        if (!less(a[mid + 1], a[mid])) return;  // 如果mid+1不是小于mid则不进行merge，提升方法1
        merge(a, aux, lo, mid, hi);
    }


    public static void main(String[] args) {
        Point[] data = new Point[4];
        data[0] = new Point(10000,0);
        data[1] = new Point(7000,3000);
        data[2] = new Point(3000,7000);
        data[3] = new Point(0,10000);

        /*
        data[0] = new Point(1,1);
        data[1] = new Point(2,2);
        data[2] = new Point(3,3);
        data[3] = new Point(4,4);
        data[4] = new Point(2,3);
        data[5] = new Point(3,4);
        data[6] = new Point(4,5);
        data[7] = new Point(5,6);

        data[8] = new Point(2,6);
        data[9] = new Point(3,7);
        data[10] = new Point(4,8);
        data[11] = new Point(5, 9);

         */

        BruteCollinearPoints bcp = new BruteCollinearPoints(data);
        StdOut.println();
        StdOut.println("segment number: " + bcp.numberOfSegments());
        StdOut.println("segment array length: " + bcp.segments().length);
        LineSegment[] ls = bcp.segments();
        for(int i = 0; i < ls.length; i++) {
            StdOut.println(ls[i].toString());
        }
    }
}
