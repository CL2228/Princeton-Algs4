import edu.princeton.cs.algs4.StdOut;
import java.util.Comparator;

public class FastCollinearPoints {
    private int segNum;
    private LineSegment[] data;

    public FastCollinearPoints(Point[] points) {
        data = new LineSegment[0];
        segNum = 0;
        if (points == null) throw new NullPointerException("?");

        Point[] points_process = new Point[points.length];
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) throw new NullPointerException("?");
            for (int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0) throw new IllegalArgumentException("?");
            }

            points_process[i] = points[i];
        }

        Point[] aux0 = new Point[points_process.length];    // auxiliary array for point indices sorting
        sort(null, points_process, aux0, 0, points_process.length - 1); // sort points by indices

        Point[] a = new Point[points_process.length - 1];   // sub array for slops sorting
        Point[] aux = new Point[points_process.length - 1]; // auxiliary array for this procedure

        for (int i = 0; i < points_process.length; i++) {
            // copy all the points to a with exception of points[i](the bar point)
            int idx = 0;
            for (int k = 0; k < i; k++)
                a[idx++] = points_process[k];
            for (int k = i + 1; k < points_process.length; k++)
                a[idx++] = points_process[k];

            // merge sort by slop with bar point(points[i[)
            sort(points_process[i].slopeOrder(), a, aux, 0, a.length - 1);
            lineDetection(points_process[i], a);
        }

        // resize the data array to consisiate segNum and array
        if (segNum < data.length) {
            LineSegment[] temp = new LineSegment[segNum];
            for (int i = 0; i < segNum; i++) temp[i] = data[i];
            data = temp;
        }

    }

    public int numberOfSegments() {
        return segNum;
    }

    public LineSegment[] segments(){
        LineSegment[] outputdata = new LineSegment[segNum];
        for (int i = 0; i < segNum; i++) {
            outputdata[i] = data[i];
        }
        return outputdata;
    }

    private void addData(Point head, Point tail) {
        if (segNum >= data.length) {            // if segment number is equal to length of data(needs expand)
            if (segNum == 0) {
                data = new LineSegment[1];
            }
            else {
                LineSegment[] temp = new LineSegment[2 * data.length];  // double the length
                for(int i = 0; i < segNum; i++)     // copy procedure
                    temp[i] = data[i];
                data = temp;
            }
        }
        data[segNum++] = new LineSegment(head, tail);   // add the new line segment
    }

    private void lineDetection(Point bar, Point[] a){
        int count = 1;
        double preSlop = 0;
        int headIndex = 0;
        for(int i = 0; i < a.length; i++) {
            if (i == 0) {       //initiate for i=0
                preSlop = bar.slopeTo(a[i]);
                headIndex = 0;
                count = 1;
            }
            else {
                if (bar.slopeTo(a[i]) == preSlop) {         // increment count when the slop remains unchanged
                    count++;
                    if ((i == a.length - 1) && count >=3){  // detect at the end of the list
                        if (bar.compareTo(a[headIndex]) < 0) {
                            addData(bar, a[i]);
                        }
                    }
                }
                else {
                    if ((count >= 3) && (bar.compareTo(a[headIndex]) < 0)) {
                        // when the slop changes and count >= 3(4 or more than 4 altogether)
                        //when bar point < head point, add to data(NMS)
                        addData(bar, a[i - 1]);
                    }
                    preSlop = bar.slopeTo(a[i]);    // update information, change slop, headindex, count
                    count = 1;
                    headIndex = i;
                }
            }
        }
    }

    private boolean less(Comparator<Point> ct, Point v, Point w) {

        if (ct == null) {
            return (v.compareTo(w) < 0);
        } else {
            return (ct.compare(v, w) < 0);
        }
    }

    private boolean isSorted(Comparator<Point> ct, Point[] a, int lo, int hi) {
        for (int i = lo; i <= hi; i++) {
            if (less(ct, a[i], a[i - 1])) return false;
        }
        return true;
    }

    private void merge(Comparator<Point> ct, Point[] a, Point[] aux, int lo, int mid, int hi) {
        //可以同时使用多种排序依据的merge
        assert isSorted(ct, a, lo, mid);
        assert isSorted(ct, a, mid + 1, hi);

        for (int k = lo; k <=hi; k++)
            aux[k] = a[k];

        int i = lo, j = mid + 1;
        for (int k = lo; k <= hi; k++) {
            if (i > mid) {
                a[k] = aux[j++];
            } else if (j > hi) {
                a[k] = aux[i++];
            } else if (less(ct, aux[j], aux[i])) {
                a[k] = aux[j++];
            } else {
                a[k] = aux[i++];
            }
        }
    }

    private void sort(Comparator<Point> ct, Point[] a, Point[] aux, int lo, int hi) {
        if (hi <= lo) return;
        int mid = lo + (hi - lo) / 2;
        sort(ct, a, aux, lo, mid);
        sort(ct, a, aux, mid + 1, hi);
        merge(ct, a, aux, lo, mid, hi);
    }

    public static void main(String[] args) {

        Point[] data = new Point[12];
        data[0] = new Point(2,3);
        data[1] = new Point(3,4);
        data[2] = new Point(4,5);
        data[3] = new Point(5,6);

        data[4] = new Point(1,1);
        data[5] = new Point(2,2);
        data[6] = new Point(3,3);
        data[7] = new Point(4,4);

        data[8] = new Point(2,6);
        data[9] = new Point(3,7);
        data[10] = new Point(4,8);
        data[11] = new Point(5, 9);

        FastCollinearPoints fcp = new FastCollinearPoints(data);
        StdOut.println("segment number: " + fcp.numberOfSegments());
        StdOut.println("segment array length: " + fcp.segments().length);
        LineSegment[] ls = fcp.segments();
        for(int i = 0; i < ls.length; i++) {
            StdOut.println(ls[i].toString());
        }
    }
}
